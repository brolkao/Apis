// bridge.js - Run with: node bridge.js
const express = require('express');
const { loadLibrary, CString, Pointer } = require('ffi-napi');
const ref = require('ref-napi');

const app = express();
app.use(express.json({ limit: '10mb' }));

const dll = loadLibrary('BHRAVENApi.dll');
const AnalyzeCode = dll.get('AnalyzeCode');
AnalyzeCode.async = true;
const FreeString = dll.get('FreeString');

app.post('/analyze', async (req, res) => {
    try {
        const { code, filename } = req.body;
        const resultPtr = await AnalyzeCode.async(code, filename || "test.py", null, true);
        const jsonResult = resultPtr.readCString();
        FreeString(resultPtr);
        res.json(JSON.parse(jsonResult));
    } catch (err) {
        res.json({ error: err.message });
    }
});

app.listen(27600, () => console.log("BHRAVEN Bridge running on http://127.0.0.1:27600"));