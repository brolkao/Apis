[DllImport("BHRAVENApi.dll", CallingConvention = CallingConvention.Cdecl)]
public static extern IntPtr AnalyzeCode(string code, string filename, string lang, bool warnings);

[DllImport("BHRAVENApi.dll", CallingConvention = CallingConvention.Cdecl)]
public static extern void FreeString(IntPtr ptr);

public static string Analyze(string code, string file = "test.cpp")
{
    IntPtr ptr = AnalyzeCode(code, file, null, true);
    string json = Marshal.PtrToStringAnsi(ptr);
    FreeString(ptr);
    return json;
}