from ctypes import cdll, c_char_p, c_bool

bh = cdll.LoadLibrary("bhravenAPI.dll")

bh.AnalyzeCode.restype = c_char_p
bh.FreeString.argtypes = [c_char_p]

def analyze(code, filename="test.py"):
    result = bh.AnalyzeCode(code.encode('utf-8'), filename.encode('utf-8'), None, True)
    json_str = result.decode('utf-8')
    bh.FreeString(result)
    return json_str

# Usage
code = """
def hello()
    print("Missing colon!")
"""
print(analyze(code, "test.py"))
