@echo off
echo Starting BHRAVEN API Bridge...
node bridge.js
pause