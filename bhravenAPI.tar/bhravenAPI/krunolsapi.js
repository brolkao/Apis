// Function to get basic device identity from userAgent and other APIs
function getDeviceIdentity() {
    const ua = navigator.userAgent;
    let identity = {
        userAgent: ua,
        platform: navigator.platform || 'Unknown',
        isMobile: /Mobi|Android/i.test(ua) ? 'Yes' : 'No',
        browser: 'Unknown',
        screenResolution: `${screen.width}x${screen.height}`,
        language: navigator.language || 'Unknown'
    };

    // Rough browser detection
    if (ua.includes('Chrome')) identity.browser = 'Chrome';
    else if (ua.includes('Firefox')) identity.browser = 'Firefox';
    else if (ua.includes('Safari') && !ua.includes('Chrome')) identity.browser = 'Safari';
    else if (ua.includes('Edge')) identity.browser = 'Edge';

    // Extract OS and device model hints (basic parsing)
    if (ua.includes('Android')) {
        identity.os = 'Android';
        const match = ua.match(/Android\s([\d.]+).*;\s([^;]+)\sBuild/);
        if (match) identity.deviceModel = match[2];
    } else if (ua.includes('iPhone') || ua.includes('iPad')) {
        identity.os = 'iOS';
        const match = ua.match(/(iPhone|iPad|iPod).*OS\s([\d_]+)/);
        if (match) identity.deviceModel = match[1] + ' (iOS ' + match[2].replace(/_/g, '.') + ')';
    } else if (ua.includes('Windows')) {
        identity.os = 'Windows';
    } else {
        identity.os = 'Unknown';
    }

    return identity;
}

// Function to get battery status (if supported)
async function getBatteryStatus() {
    if ('getBattery' in navigator) {
        try {
            const battery = await navigator.getBattery();
            return {
                level: Math.round(battery.level * 100) + '%',
                charging: battery.charging ? 'Yes' : 'No',
                chargingTime: battery.chargingTime === Infinity ? 'N/A' : battery.chargingTime + ' seconds',
                dischargingTime: battery.dischargingTime === Infinity ? 'N/A' : battery.dischargingTime + ' seconds'
            };
        } catch (error) {
            return { error: 'Unable to access battery info: ' + error.message };
        }
    } else {
        return { error: 'Battery API not supported in this browser.' };
    }
}

// Function to get online status
function getOnlineStatus() {
    return {
        online: navigator.onLine ? 'Yes' : 'No',
        connectionType: navigator.connection ? navigator.connection.effectiveType : 'Unknown (Connection API not supported)'
    };
}

// Main function to display info
async function displayInfo() {
    const identity = getDeviceIdentity();
    const battery = await getBatteryStatus();
    const online = getOnlineStatus();

    let output = '<h2>Device Identity</h2>';
    output += `<p><strong>User Agent:</strong> ${identity.userAgent}</p>`;
    output += `<p><strong>Platform:</strong> ${identity.platform}</p>`;
    output += `<p><strong>Is Mobile:</strong> ${identity.isMobile}</p>`;
    output += `<p><strong>Browser:</strong> ${identity.browser}</p>`;
    output += `<p><strong>OS:</strong> ${identity.os}</p>`;
    output += `<p><strong>Device Model:</strong> ${identity.deviceModel || 'Unknown'}</p>`;
    output += `<p><strong>Screen Resolution:</strong> ${identity.screenResolution}</p>`;
    output += `<p><strong>Language:</strong> ${identity.language}</p>`;

    output += '<h2>Phone Status</h2>';
    output += `<p><strong>Online:</strong> ${online.online}</p>`;
    output += `<p><strong>Connection Type:</strong> ${online.connectionType}</p>`;
    if (battery.error) {
        output += `<p><strong>Battery Info:</strong> ${battery.error}</p>`;
    } else {
        output += `<p><strong>Battery Level:</strong> ${battery.level}</p>`;
        output += `<p><strong>Charging:</strong> ${battery.charging}</p>`;
        output += `<p><strong>Charging Time:</strong> ${battery.chargingTime}</p>`;
        output += `<p><strong>Discharging Time:</strong> ${battery.dischargingTime}</p>`;
    }

    document.getElementById('info').innerHTML = output;
}

// Run on page load
window.onload = displayInfo;
